const ITEMS1 = require('./firSample.js')
const ITEMS2 = require('./secSample.js')
const ITEMS3 = require('./thirSample.js')
const ITEMS4 = require('./forSample.js')

const ARR1 = ITEMS1.items(); // 89
const ARR2 = ITEMS2.items(); // 187
const ARR3 = ITEMS3.items(); // 

const ITEMS = ARR1.concat(ARR2, ARR3)

console.log(ARR1.length)
console.log(ARR2.length)
console.log(ARR3.length)
console.log(ITEMS.length)
