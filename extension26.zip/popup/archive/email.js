export function axios(){
    require('axios').default;
}

// module.exports = require('axios').default;