const axios = require('axios');

// https://stackoverflow.com/questions/38296667/getting-unexpected-token-export
const importItems = require('./arraySample.js')
// const items = importItems.items();
const items = importItems.newItems();
// console.log('items: ',items)

const username = "Insub" 
const useremail = "insub@mail.com" 

const config = { 
  headers: {
    'Content-Type': 'application/json', 
    'Authorization' : 'Bearer pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069'
  }
} 

const contactUrl = "https://api.hubapi.com/crm/v3/objects/contacts";
const dealUrl = "https://api.hubapi.com/crm/v3/objects/deals";

let dealIdArr = new Array();
let contactIdArr = new Array();

let j = 0;

// Execution order //

// 1. excGetContactByEmail
// 2. excCreateDeal
// 3. excCreateAssociation


function GetContactByEmail() {
  console.log("")
  console.log("GetContactByEmail starts")
  let cleanedEmail = items[j][10].toLowerCase().replace(/pty|ltd.|ltd|limited/g, '').replace(/[^a-z0-9@.]/gi, '')
  console.log("Cleaned email: ", cleanedEmail)

  // i iterates here from 0 to end
  axios.get(contactUrl.concat('/',cleanedEmail, '?idProperty=email'), config)
  // When i gets here, i is already 3
  .then(function (response) {
    // handle success
    //   console.log(response.data)
    console.log("")
    // console.log("found contactEmail/" + items[j][10]);
    console.log("found contactEmail/" + cleanedEmail);
    console.log("GetContactByEmail axios response");

    console.log("GetContactByEmail response")
    // console.log("found contactEmail/" + contactEmail + ":" + response.data);

    // get their contactid

  })
  .catch(function (error) {
    console.log("")
    console.log(cleanedEmail)
    console.log("GetContactByEmail error")
    //
    // Cannot get i from here
    
    // if email doesn't exists, create an email address beforehand:
    // email : no_email@company_name.com --> company_name is used as Primary company in HubSpot

    // handle error
    // console.log(error.response.status);
    if (error.response.status === 404) {
      console.log("404 - Email address is NOT found")
      console.log("Create a new email address")

      let company = items[j][3]
      let email = cleanedEmail
      let phone = items[j][11]

      if (email === "" || !email.includes("@")) {
        // .replace(/\s/g, '') remove white spaces
        email = "no_email@" + company.toLowerCase().replace(/pty|ltd.|ltd|limited/g, '').replace(/[^a-z0-9]/gi, '') + ".com" // remove a white space with
        console.log("no_email is created: ", email)
      }

      if (phone.includes("+61")){
        // pass
      } else if(phone.length === 12){ // pass
      } else if (phone.length === 10) { // 1111222333 -> 1111 222 333
          let phone1 = phone.slice(0, 4);
          let phone2 = phone.slice(4, 7);
          let phone3 = phone.slice(7, 10);

          phone = phone1 + " " + phone2 + " " + phone3
      
          // console.log(phone);
      } else {
          // phone = "0000 000 000";
      }
      
      // create a new contact
      const newContactData = {
        properties: {
          company: company,
          email: email,
          phone: phone,
          // website: "new.biglytics.net",
          // hubspot_owner_id: "229866130",
        }
      }

      // CreateContact - Create new contract
      CreateContact(newContactData)
    } // if statement
    
    j ++;

  })  // catch
}

function GetContact(contactId) {
  axios.get(contactUrl.concat('/',contactId), config)
  .then(function (response) {
    // handle success
    console.log("found contactId/", contactId,":",response.data);
  })
  .catch(function (error) {
    // handle error
    console.log(error)
  })  
}

function CreateContact(contactData) {

  axios.post(contactUrl, contactData, config)
  .then(function (response) {
    // handle success
    console.log("")
    console.log("successfully added new contact:",response.data.id);
    console.log("CreateContact response")
    // Append contact id to contactIdArr 
    contactIdArr.push(response.data.id)
    // console.log(contactIdArr)
    
    // return(response.data.id)
  })
  .catch(function (error) {
    // handle error      
      console.log("")
      console.log("CreateContact error: ", error.response.status)

      if (error.response.status === 409){
        let getID = error.response.data.message;
        // Extract numbers and join them without spaces -- e.g. ["3", "5", "5"] -> 355
        getID = getID.match(/\d/g).join("");

        // Show existing ID 
        console.log(error.response.data.message)        
        // Add to contactIdArr
        contactIdArr.push(getID)
        
      }
      console.log(contactIdArr)
    }) // catch
}

function CreateDeal (dealData) {
  console.log("")
  console.log("CreateDeal starts")
  
  axios.post(dealUrl, dealData, config)
  .then(function (response) {
    console.log("")
    console.log("CreateDeal response")
    // handle success
    console.log("successfully created deal with dealId:",response.data.id);
    // Append deal id to dealIdArr 
    dealIdArr.push(response.data.id)
    // return response.data.id;
  })
  .catch(function (error) {
    console.log("")
    console.log("CreateDeal error")
    // handle error
    // console.log(error);
  })
}


function CreateAssociation(dealID, contactID){
  
  console.log("CreateAssociation starts ")
  console.log(dealID +", " + contactID)

  let associationUrl = "https://api.hubapi.com/crm/v4/objects/deals/"+dealID+"/associations/contacts/"+contactID;
  const associationData = [ 
    {
      "associationCategory": "HUBSPOT_DEFINED",
      "associationTypeId": 3
    }
  ]
  console.log(associationUrl)
  axios.put(associationUrl, associationData, config)
  
  .then(function (response) {
    // handle success
    console.log("")
    console.log("successfully associated:", response.data);
    console.log("Association response")
  })
  .catch(function (error){
    console.log("")
    console.log("Association error")
    //handle error
    // console.log(error);

  })  

}

function excCreateContact () {
  for (var i = 0; i < items.length; i ++){
    
    let contactData = 
    {
      properties: {
        fisrtname: items[i][9],
        email: items[i][10],
        phone: items[i][11],
        // website: "biglytics.net",
        // primarycompany: "",
        // leadstatus: "",
      }
  }
    
    // console.log(i + ". company: " + items[i][3])  

    CreateContact(contactData)
    // break;
  }
}


function excGetContactByEmail (callbackexcCreateDeal) {
  // https://stackoverflow.com/questions/3583724/how-do-i-add-a-delay-in-a-javascript-loop
  setTimeout(function () {}, 1000)
  
  console.log("===========================")
  console.log("No: ", j)
  console.log("excGetContactByEmail starts")

  GetContactByEmail()

      setTimeout(function() {
        // if (j === 1){
        if (j === items.length){
          setTimeout(function () {
            console.log("")
            console.log("excGetContactByEmail callback starts")
            callbackexcCreateDeal()
          }, 1000)
        }

        if (j < items.length){
          excGetContactByEmail(excCreateDeal)
          j++;
        }
        j--;
      }, 1500)

    // https://community.hubspot.com/t5/HubSpot-Ideas/Get-contact-by-email-api-v3/idi-p/463473
  }
    

let m = 0; 

function wordContains(target, pattern){
  // https://stackoverflow.com/questions/37896484/multiple-conditions-for-javascript-includes-method
  // https://www.w3schools.com/jsref/jsref_foreach.asp
    var value = 0;
    // Take each element from pattern, in this case supPlusArr 
    pattern.forEach(function(word){ 
        // console.log("Word: ", word)
        // If target includes a word, then target.includes(word) returns 1
        value = value + target.includes(word);
        // console.log(value)
      });
    return (value >= 1)
  }

function excCreateDeal (callbackexcCreateAssociation) {
  console.log("No: ", j)
  // Reset j
  if (j === items.length-1 & m === 0){
    j = 0;
    m ++;
  }

  setTimeout(function() {}, 2000)

  if (j === items.length){
    setTimeout(function(){
      console.log("")
      console.log("excCreateAssociation callback starts")
      callbackexcCreateAssociation()
    }, 3000)
  }

  console.log("===========================")
  console.log("excCreateDeal starts")

  if (j < items.length){

      let inputAmountStr = "";
      let indices = new Array;
      

    if ((items[j][8] == "") || (items[j][8].match(/\d+/g) == null)) {
      console.log("if true")
      inputAmountStr = "0"
    } else {
      console.log("if false")
      inputAmountStr = items[j][8]
    }

    inputAmountStr = inputAmountStr.toLowerCase();

    for(var i=0; i<inputAmountStr.length;i++) {
      if (inputAmountStr[i] === "$") indices.push(i);
    }
    
    if (indices.length === 2 && inputAmountStr.substring(indices[0],indices[1]).includes("k")) {
      inputAmountStr = inputAmountStr.replace("k", "000")
    };

    const rates = inputAmountStr.match(/\d+/g); // Take only numbers
    let supInclRate = "";

    const supExclArr = ["+ plus super","+super","+ super","+ superannuation", "plus super", "plus superannuation","exclude super","excluding super","excl super","excl of super"];

    console.log("items[j][8]: ", items[j][8])
    console.log("rates[0]: ", rates)

    if (rates[0] > 300 && rates[0] < 3000){
      if (wordContains(inputAmountStr, supExclArr) == 1) {
        console.log("Supper is excluded: ", rates[0])
        console.log("Supper added rate: ", rates[0]*1.105)
        supInclRate = rates[0]*1.105
        
      } else { // when 0, meaning that super is inclusive  
        console.log("Supper included rate: ", rates[0])
        supInclRate = rates[0]
      }

    } else { 
      // if the first number is not greater than 1000 
      // showing the full details and add it to invalidAd
    
      console.log("")
      console.log("==============")
      console.log("Invalid Job Ad:")
      console.log("   ",inputAmountStr)
      console.log("==============")
      console.log("")
    
      supInclRate = "0"
    }
      
      let dealData = 
      {
        properties: {            
      dealname: username + " - " + items[j][3] + " - " + items[j][2], // username - company_name - title
      dealstage:"presentationscheduled",
      closedate:"",
      hubspot_owner_id:"229866130", // owner
      amount: supInclRate,       // amount
      seekurl: items[j][0],
      amountdetail: items[j][8],
      pipeline:"default",
        }
      }
    // console.log(dealData)
    CreateDeal(dealData)
  }

  setTimeout(function () {
    if (j < items.length){
      j++;
      excCreateDeal(excCreateAssociation)
    }
  }, 1000)

}

function excCreateAssociation (){

  console.log("No: ", j)
  // Reset j
  if (j === contactIdArr.length & m === 1){
    j = 0;
    m ++;
  }

  setTimeout(function() {}, 1000)

  if (j == contactIdArr.length){
    console.log("===========================")
    console.log("= Sending to HubSpot ends =")
    console.log("===========================")
  }
  console.log("===========================")
  console.log("excCreateAssociation starts")
  
  console.log("")
  console.log(dealIdArr[j] + ", " + contactIdArr[j])
  
  CreateAssociation(dealIdArr[j], contactIdArr[j])
  
  setTimeout(function () {
    
    if (j < contactIdArr.length){
      j++;
      excCreateAssociation()
    }

  }, 1000)
}


// https://stackoverflow.com/questions/13421975/calling-three-subsequent-callback-functions
excGetContactByEmail(excCreateDeal)
// excCreateDeal()

