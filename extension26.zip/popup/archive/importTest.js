const axios = require('axios').default;
const items = [
  [
  "https://www.seek.com.au/job/58659137?type=promoted#sol=195554365d3bca54ac6f11b84d4b6fb442089f76",
  "",
  "Data Analyst",
  "Charterhouse",
  "ProfileSaved searchesSaved jobsApplied jobsRecommended jobsSettingsHong KongIndonesiaMalaysiaNew ZealandPhilippinesSingaporeThailandCoursesBusinesses for saleVolunteering 12d ago",
  "Contract/Temp",
  "",
  "Sydney NSW",
  "$800 per day + Super",
  "jack on jack@charterhouse.com.au for a confidential discussion.  www.charterhouse.com.au",
  "Jack@Charterhouse.com.au",
  "",
  "",
  "10/11/2022 1:52:11 PM"
  ]
]

const config = { 
    headers: {
        'Content-Type': 'application/json', 
        'Authorization' : 'Bearer pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069'
    }
} 

const companytUrl = "https://api.hubapi.com/crm/v3/objects/companies";
const contactUrl = "https://api.hubapi.com/crm/v3/objects/contacts";
const dealUrl = "https://api.hubapi.com/crm/v3/objects/deals";


const companyData = 
{
    properties: {
      name: items[0][3],
      // hubspot_owner_id: "229866130", // owner
      phone: items[0][11],
      city: items[0][7],
      // state: "NSW",
      // industry: "Technology",
    }
}

const contactData = 
{
    properties: {
      fisrtname: items[0][9],
      email: items[0][10],
      phone: items[0][11],
      // website: "biglytics.net",
      // primarycompany: "",
      // leadstatus: "",
    }
}

let dealData = 
{
    properties: {            
      dealname: username + " - " + items[0][3] + " - " + items[0][2], // username - company_name - title
      dealstage:"presentationscheduled",
      closedate:"",
      hubspot_owner_id:"229866130", // owner
      dealvalue: items[0][8],       // amount
      seekurl: items[0][0],
      pipeline:"default",
    }
}


function CreateDeal (dealData) {
    axios.post(dealUrl, dealData, config)
    .then(function (response) {
      // handle success
      console.log("successfully created deal with dealId:",response.data.dealId);
      return response.data.dealId;
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })  
}

function CreateContact(contactData) {
    axios.post(contactUrl, contactData, config)
    .then(function (response) {
      // handle success
      console.log("successfully added new contact:",response.data);
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })  

}

// associate deals with contacts
function CreateAssociation(dealID, contactID){
    var associationUrl = "https://api.hubapi.com/crm/v4/objects/deals/"+dealID+"/associations/contacts/"+contactID
    var associationData = [ 
        {
            "associationCategory": "HUBSPOT_DEFINED",
            "associationTypeId": 3
        }
    ]
    
    axios.put(associationUrl, associationData, config)

    .then(function (response) {
        // handle success
        console.log("successfully associated:", response.data);
    })
    .catch(function (error){
        //handle error
        console.log(error);
    })        
}

// https://community.hubspot.com/t5/HubSpot-Ideas/Get-contact-by-email-api-v3/idi-p/463473
function GetContactByEmail(contactEmail) {
    axios.get(contactUrl.concat('/',contactEmail, '?idProperty=email'), config)
    
    .then(function (response) {
      // handle success
    //   console.log(response.data)
      console.log("found contactEmail/", contactEmail,":",response.data);
    })
    .catch(function (error) {
      // handle error
      console.log(error);
      if (error.response.status = 404) {
        console.log("404 - Email address is NOT found")

        // create a new contact
        let newContactData = {
            properties: {
              company: "NewBiglytics",
              email: contactEmail,
              firstname: "NewBryan",
              lastname: "NewCooper",
              phone: "(111) 929-0687",
              website: "new.biglytics.net",
              hubspot_owner_id: "229866130",
            }
        }
        CreateContact(newContactData)
      }
    })  
}

function GetContact(contactId) {
    axios.get(contactUrl.concat('/',contactId), config)
    .then(function (response) {
      // handle success
      console.log("found contactId/", contactId,":",response.data);
    })
    .catch(function (error) {
      // handle error
      console.log(error)
    })  
}

function GetContacts() {
    axios.get(contactUrl, config)
    .then(function (response) {
      // handle success
      console.log("contacts:",response.data);
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })  
}


function GetDeal(dealID) {
    const url = dealUrl.concat("/", dealID);
    axios.get(url, config)
    .then(function (response) {
        // handle success
        if (response) console.log(response.data);
        return response.data;
    })
    .catch((error) => {
        // handle error
        console.log(error);
    })
    .then(() => {
        // always executed
        console.log("finished...");
    })
}


const dealID = "10297793099";
const contactID = "52";
// CreateContact(sampleContactData);
// GetContacts();
// GetContact(contactID);
GetContactByEmail("NEW_bcooper@biglytics.net");
// GetDeal(dealID);
// CreateAssociation(dealID, contactID);

module.exports.GetContacts = GetContacts;
module.exports.GetContact = GetContact;
module.exports.CreateContact = CreateContact;
module.exports.CreateDeal = CreateDeal;
module.exports.CreateAssociation = CreateAssociation;