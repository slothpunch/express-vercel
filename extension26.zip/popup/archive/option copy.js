// Select location value
// import {toProfile} from "./script.js"


$(function(){
// *** Setting Limit ***
// select limit button of click event from user
    chrome.storage.local.get(['items'], function (data) {
        let items = [];
        if (data['items'] && (data['items'] != 'undefined'))
            items = data['items'];

            alert(items[0][14] + " first") // name
            alert(items[0][15] + " first") // email

    $('#btnSave').click(function(){
            // Get the existing time value from input box
            let item = [];

            let name = "";
            let email = "";
            
            name = $('#name').val();
            email = $('#email').val();

            // if there's name set, then
            if(name === "" || email === ""){
            // add this limit into storage
                alert("name and email required")
            };
            console.log(name, " ", email);

            if(name !== "" && email !== ""){
                alert(name + ", " + email + " - saved")
                alert("This page is closing")
            
            
            item.push(name);
            item.push(email);
            
            items.push(item)
            alert(items)
            chrome.storage.local.set({
                items: items
            }, function () {
                chrome.runtime.sendMessage({
                    from: 'content',
                    subject: 'loadResults'
                });
            
            // close();
            alert(items[14] + " sec") // name
            alert(items[15] + " sec") // email
            })
        }
    })
})});