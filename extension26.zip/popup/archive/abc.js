const axios = require('axios').default;

const config = { 
    headers: {
        'Content-Type': 'application/json', 
        'Authorization' : 'Bearer pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069'
    }
} 

const dealUrl = "https://api.hubapi.com/crm/v3/objects/deals";
const contactUrl = "https://api.hubapi.com/crm/v3/objects/contacts";

const sampleDealData = {
  properties:   {            
    "dealname": items[i][1] + " - " + items[i][3] + " - " + items[i][2],
    "dealstage":"presentationscheduled",
    "closedate":"2029-12-07T16:50:06.678Z",
    "hubspot_owner_id":"910901", // deal owner
    "dealvalue": items[i][8],
    "seekurl": items[i][0],
    "pipeline":"default",
  }
}

     
const sampleContactData = 

{
    properties: {
        company: "Biglytics",
        email: "bcooper@biglytics.net",
        firstname: "Bryan",
        lastname: "Cooper",
        phone: "(877) 929-0687",
        website: "biglytics.net"
    }
}

function CreateDeal (dealData) {
    axios.post(dealUrl, dealData, config)
    .then(function (response) {
      // handle success
      console.log("successfully created deal with dealId:",response.data.dealId);
      return response.data.dealId;
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })  
}

function CreateContact(contactData) {
    axios.post(contactUrl, contactData, config)
    .then(function (response) {
      // handle success
      console.log("successfully added new contact:",response.data);
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })  

}

// associate deals with contacts
function CreateAssociation(dealID, contactID){
    var associationUrl = "https://api.hubapi.com/crm/v4/objects/deals/"+dealID+"/associations/contacts/"+contactID
    var associationData = [ 
        {
            "associationCategory": "HUBSPOT_DEFINED",
            "associationTypeId": 3
        }
    ]
    
    axios.put(associationUrl, associationData, config)

    .then(function (response) {
        // handle success
        console.log("successfully associated:", response.data);
    })
    .catch(function (error){
        //handle error
        console.log(error);
    })        
}

// https://community.hubspot.com/t5/HubSpot-Ideas/Get-contact-by-email-api-v3/idi-p/463473
function GetContactByEmail(contactEmail) {
    axios.get(contactUrl.concat('/',contactEmail, '?idProperty=email'), config)
    
    .then(function (response) {
      // handle success
    //   console.log(response.data)
      console.log("found contactEmail/", contactEmail,":",response.data);
    })
    .catch(function (error) {
      // handle error
      console.log(error);
      if (error.response.status = 404) {
        console.log("404 - Email address is NOT found")

        // create a new contact
        let newContactData = {
            properties: {
              company: "NewBiglytics",
              email: contactEmail,
              firstname: "NewBryan",
              lastname: "NewCooper",
              phone: "(111) 929-0687",
              website: "new.biglytics.net",
              hubspot_owner_id: "229866130",
            }
        }
        CreateContact(newContactData)
      }
    })  
}

function GetContact(contactId) {
    axios.get(contactUrl.concat('/',contactId), config)
    .then(function (response) {
      // handle success
      console.log("found contactId/", contactId,":",response.data);
    })
    .catch(function (error) {
      // handle error
      console.log(error)
    })  
}

function GetContacts() {
    axios.get(contactUrl, config)
    .then(function (response) {
      // handle success
      console.log("contacts:",response.data);
    })
    .catch(function (error) {
      // handle error
      console.log(error);
    })  
}


function GetDeal(dealID) {
    const url = dealUrl.concat("/", dealID);
    axios.get(url, config)
    .then(function (response) {
        // handle success
        if (response) console.log(response.data);
        return response.data;
    })
    .catch((error) => {
        // handle error
        console.log(error);
    })
    .then(() => {
        // always executed
        console.log("finished...");
    })
}


const dealID = "10297793099";
const contactID = "52";
// CreateContact(sampleContactData);
// GetContacts();
// GetContact(contactID);
GetContactByEmail("NEW_bcooper@biglytics.net");
// GetDeal(dealID);
// CreateAssociation(dealID, contactID);

module.exports.GetContacts = GetContacts;
module.exports.GetContact = GetContact;
module.exports.CreateContact = CreateContact;
module.exports.CreateDeal = CreateDeal;
module.exports.CreateAssociation = CreateAssociation;