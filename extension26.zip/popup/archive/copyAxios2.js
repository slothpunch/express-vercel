// const { CollectionResponsePublicOwnerForwardPaging } = require('@hubspot/api-client/lib/codegen/crm/owners');
const axios = require('axios');

// const items = [
//   [
//   "https://www.seek.com.au/job/58659137?type=promoted#sol=195554365d3bca54ac6f11b84d4b6fb442089f76",
//   "",
//   "Data Analyst",
//   "Charterhouse",
//   "ProfileSaved searchesSaved jobsApplied jobsRecommended jobsSettingsHong KongIndonesiaMalaysiaNew ZealandPhilippinesSingaporeThailandCoursesBusinesses for saleVolunteering 12d ago",
//   "Contract/Temp",
//   "",
//   "Sydney NSW",
//   "$800 per day + Super",
//   "jack on jack@charterhouse.com.au for a confidential discussion.  www.charterhouse.com.au",
//   "Jack@Charterhouse.com.au",
//   "",
//   "",
//   "10/11/2022 1:52:11 PM"
//   ]
// ]

const items = [
  [
      "https://www.seek.com.au/job/58659137?type=promoted#sol=195554365d3bca54ac6f11b84d4b6fb442089f76",
      "",
      "Data Analyst",
      "Charterhouse",
      "ProfileSaved searchesSaved jobsApplied jobsRecommended jobsSettingsHong KongIndonesiaMalaysiaNew ZealandPhilippinesSingaporeThailandCoursesBusinesses for saleVolunteering 12d ago",
      "Contract/Temp",
      "",
      "Sydney NSW",
      "$800 per day + Super",
      "jack on jack@charterhouse.com.au for a confidential discussion.  www.charterhouse.com.au",
      "Jack@Charterhouse.com.au",
      "",
      "",
      "10/11/2022 1:52:11 PM"
  ],
  [
      "https://www.seek.com.au/job/58657247?type=standard#sol=294675119afaa28b7c72f5cd9b2a9fd3d0caefe0",
      "",
      "Data Analyst",
      "Ashdown People",
      "ProfileSaved searchesSaved jobsApplied jobsRecommended jobsSettingsHong KongIndonesiaMalaysiaNew ZealandPhilippinesSingaporeThailandCoursesBusinesses for saleVolunteering 12d ago",
      "Contract/Temp",
      "",
      "Sydney NSW",
      "$700 pd plus super",
      "guy@ashdownpeople.com.au or call 0406620562",
      "guy@ashdownpeople.com.au",
      "0406620562",
      "",
      "10/11/2022 2:53:10 PM"
  ],
  [
      "https://www.seek.com.au/job/58634388?type=standard#sol=fd5cb952e8fb4830b0348df05a1c91137aff5bf7",
      "",
      "Data Analyst",
      "Capital Talent Consulting Pty Ltd",
      "ProfileSaved searchesSaved jobsApplied jobsRecommended jobsSettingsHong KongIndonesiaMalaysiaNew ZealandPhilippinesSingaporeThailandCoursesBusinesses for saleVolunteering 13d ago",
      "Contract/Temp",
      "Our client is the leading global technology organisation with a brand known by all except maybe the populations of the remotest lands on the earth.. big call right?",
      "Sydney NSW",
      "$390 a day plus super",
      "",
      "",
      "0413 742 439",
      "",
      "10/11/2022 2:53:12 PM"
  ],
  [
      "https://www.seek.com.au/job/58718999?type=standout#sol=199a03aeea316ac016481fbf06e7a98eed4c7c3c",
      "",
      "Business Intelligence Analyst",
      "Troocoo",
      "ProfileSaved searchesSaved jobsApplied jobsRecommended jobsSettingsHong KongIndonesiaMalaysiaNew ZealandPhilippinesSingaporeThailandCoursesBusinesses for saleVolunteering 6d ago",
      "Contract/Temp",
      "",
      "Sydney NSW",
      "$800 - $1000 including super",
      "",
      "",
      "",
      "",
      "10/11/2022 2:53:17 PM"
  ]
]

const username = "Insub" 

const config = { 
  headers: {
      'Content-Type': 'application/json', 
      'Authorization' : 'Bearer pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069'
  }
} 

const contactUrl = "https://api.hubapi.com/crm/v3/objects/contacts";
const dealUrl = "https://api.hubapi.com/crm/v3/objects/deals";

function test(){
  for (let i = 0; i < items.length; i ++){
  
  console.log("Iteration " + (i+1) + " starts")
  
  let companyData = 
  {
      properties: {
        name: items[i][3],
        // hubspot_owner_id: "229866130", // owner
        phone: items[i][11],
        city: items[i][7],
        // state: "NSW",
        // industry: "Technology",
      }
    }
    
    let contactData = 
    {
      properties: {
        fisrtname: items[i][9],
        email: items[i][10],
        phone: items[i][11],
        // website: "biglytics.net",
        // primarycompany: "",
        // leadstatus: "",
      }
    }
    
    let dealData = 
    {
      properties: {            
        dealname: username + " - " + items[i][3] + " - " + items[i][2], // username - company_name - title
        dealstage:"presentationscheduled",
        closedate:"",
        hubspot_owner_id:"229866130", // owner
        dealvalue: items[i][8],       // amount
        seekurl: items[i][0],
        pipeline:"default",
      }
    }

  }
}

let dealIdArr = new Array();
let contactIdArr = new Array();
let contactDataArr = new Array();

function addArr(arr){
  console.log("Arr is: " + arr)
  contactIdArr.push(arr)
}

function arrayCheck () {
  console.log(dealIdArr)
  console.log(contactIdArr)
}

// Execution order //

// 1. excGetContactByEmail
// 2. excCreateDeal
// 3. excCreateAssociation



let j = 0;

function GetContactByEmail() {
  console.log("")
  console.log("GetContactByEmail starts")
  // console.log("First email add: " + contactEmail)
  // console.log("First j is: " + j)

  // i iterates here from 0 to end

  // GetContactByEmail axios starts

  axios.get(contactUrl.concat('/',items[j][10].toLowerCase(), '?idProperty=email'), config)
  // When i gets here, i is already 3
  .then(function (response) {
    // handle success
    //   console.log(response.data)
    console.log("")
    console.log("found contactEmail/" + items[j][10]);
    console.log("GetContactByEmail axios response");

    console.log("GetContactByEmail response")
    // console.log("found contactEmail/" + contactEmail + ":" + response.data);

    // get their contactid


  })
  .catch(function (error) {
    console.log("")
    console.log(items[j][10].toLowerCase())
    console.log("GetContactByEmail error")
    //
    // Cannot get i from here
    //
    
    // console.log("Second email add: " + items[j][10])
    // console.log("Second j is: " + j)

    // When email and phone number are missing, data get mixed up.
    // Before sending the data to HubSpot, if their email and phone number are missing,
    
    // put data beforehand:
    // email : no_email@company_name.com --> company_name is used as Primary company in HubSpot
    // phone : 0000 000 000        
    // }

    // handle error
    // console.log(error.response.status);
    if (error.response.status === 404) {
      console.log("404 - Email address is NOT found")
      console.log("Create a new email address")
      // console.log(items[j])

      let company = items[j][3]
      let email = items[j][10]
      // let email = contactEmail // it seems like contactEmail gets corrupted while going through the code
      let phone = items[j][11]

      if (email === "" || !email.includes("@")) {
        email = "no_email@" + company.toLowerCase().replace(/\s/g, '') + ".com"
        console.log("no_email is created: ", email)
      }

      if (phone.includes("+61")){
        // console.log(phone); // pass
      } else if(phone.length === 12){ // pass
      } else if (phone.length === 10) { // 1111222333 -> 1111 222 333
          let phone1 = phone.slice(0, 4);
          let phone2 = phone.slice(4, 7);
          let phone3 = phone.slice(7, 10);

          phone = phone1 + " " + phone2 + " " + phone3
      
          // console.log(phone);
      } else {
          phone = "0000 000 000";
      }
      
      // create a new contact
      const newContactData = {
        properties: {
          company: company,
          email: email,
          phone: phone,
          // website: "new.biglytics.net",
          // hubspot_owner_id: "229866130",
        }
      }
      // console.log("newContactData: ", newContactData)
      // Add newContactData to contactDataArr 
      contactDataArr.push(newContactData)
      // CreateContact - Create new contract
      setTimeout(function() {}, 2000)
      CreateContact()
    } // if statement
    
    j ++;
    k ++;
    // pause()
  })  // catch
}

function GetContact(contactId) {
  axios.get(contactUrl.concat('/',contactId), config)
  .then(function (response) {
    // handle success
    console.log("found contactId/", contactId,":",response.data);
  })
  .catch(function (error) {
    // handle error
    console.log(error)
  })  
}

let k = 0;

function CreateContact() {
  // data is changed when it gets data from GetContactByEamil()

  // console.log(contactDataArr)

  // let contactData = contactDataArr[k]
  // console.log(contactDataArr[k])

  // console.log("contactDataArr nown ownow:", contactDataArr)
  // let k = 1;

  // k ++;
  // axios.interceptors.request.use(request => {
  //   console.log('Starting Request', JSON.stringify(request, null, 2))
  //   return request
  // })
  // axios.post(contactUrl, contactDataArr[k], config)
  axios.post(contactUrl, contactDataArr[k], config)
  // contactData gets minxed up, WHY??????
  .then(function (response) {
    // handle success
    console.log("")
    console.log("successfully added new contact:",response.data.id);
    console.log("CreateContact response")
    // Append contact id to contactIdArr 
    contactIdArr.push(response.data.id)
    console.log(contactIdArr)
    
    // return(response.data.id)
  })
  .catch(function (error) {
    // handle error
      // console.log("First error")
      // console.log(error);
      
      // console.log("")
      // console.log("k: ", k) // shows 4

      console.log("")
      console.log("contactDataArr[k]: ", contactDataArr[k]) // contactDataArr[4]
      // console.log("contactData: ", contactData) // data is changed
      
      console.log("")
      console.log("CreateContact error")

      // console.log("error here")
      // console.log(error)        

      if (error.response.status === 409){
        let getID = error.response.data.message;
        // Extract numbers and join them without spaces -- e.g. ["3", "5", "5"] -> 355
        getID = getID.match(/\d/g).join("");


        // Show existing ID 
        console.log(error.response.data.message)        
        // Add to contactIdArr
        contactIdArr.push(getID)
        
      }
      console.log(contactIdArr)
      // k++;
    }) // catch
}

function CreateDeal (dealData) {
  console.log("")
  console.log("CreateDeal starts")
  // console.log("Seoncd I is: " + i)  
  // console.log("")  
  axios.post(dealUrl, dealData, config)
  .then(function (response) {
    console.log("")
    console.log("CreateDeal response")
    // handle success
    console.log("successfully created deal with dealId:",response.data.id);
    // Append deal id to dealIdArr 
    dealIdArr.push(response.data.id)
    // return response.data.id;
  })
  .catch(function (error) {
    console.log("")
    console.log("CreateDeal error")
    // handle error
    console.log(error);
  })

  // console.log("")
  // console.log("Current dealIdArr: " + dealIdArr)
}


function CreateAssociation(dealID, contactID){
  
  console.log("CreateAssociation starts ")
  console.log(dealID +", " + contactID)

  let associationUrl = "https://api.hubapi.com/crm/v4/objects/deals/"+dealID+"/associations/contacts/"+contactID;
  const associationData = [ 
    {
      "associationCategory": "HUBSPOT_DEFINED",
      "associationTypeId": 3
    }
  ]
  console.log(associationUrl)
  axios.put(associationUrl, associationData, config)
  
  .then(function (response) {
    // handle success
    console.log("")
    console.log("successfully associated:", response.data);
    console.log("Association response")
  })
  .catch(function (error){
    console.log("")
    console.log("Association error")
    //handle error
    // console.log(error);

  })  

}

function excCreateContact () {
  for (var i = 0; i < items.length; i ++){
    
    let contactData = 
    {
      properties: {
        fisrtname: items[i][9],
        email: items[i][10],
        phone: items[i][11],
        // website: "biglytics.net",
        // primarycompany: "",
        // leadstatus: "",
      }
  }
    
    // console.log(i + ". company: " + items[i][3])  

    CreateContact(contactData)
    // break;
  }
}

contactCom = new Array();
function excGetContactByEmail (callbackexcCreateDeal) {
    // https://stackoverflow.com/questions/3583724/how-do-i-add-a-delay-in-a-javascript-loop
  setTimeout(function () {}, 1000)

  console.log("===========================")
  console.log("excGetContactByEmail starts")
    
    // for(var i = 0; i < items.length; i ++){
    GetContactByEmail()
    console.log("First ",j);
      setTimeout(function() {
        // GetContactByEmail()
        console.log("Second ",j);
        if (j < items.length){
          console.log("j inside if ",j);
          excGetContactByEmail()
          j++;
        }
        j--;
      }, 3000)
      console.log("Before ",j);
      // j++;
      console.log("After ",j);
    // https://community.hubspot.com/t5/HubSpot-Ideas/Get-contact-by-email-api-v3/idi-p/463473
    // GetContactByEmail() // items[0][10] - company email address Jack@Charterhouse.com.au
    // break;
    // contactCom.push(items[i][3])
    if (j === items.length){
      setTimeout(function () {
        console.log("")
        console.log("excGetContactByEmail callback starts")
        callbackexcCreateDeal(excCreateAssociation)
      }, 3000)
    }
  }
    

// }

dealCom = new Array();
function excCreateDeal (callbackexcCreateAssociation) {

  setTimeout(function() {}, 3000)

  console.log("===========================")
  console.log("excCreateDeal starts")

  for (var i = 0; i < items.length; i ++){
    
    let dealData = 
    {
      properties: {            
        dealname: username + " - " + items[i][3] + " - " + items[i][2], // username - company_name - title
        dealstage:"presentationscheduled",
        closedate:"",
        hubspot_owner_id:"229866130", // owner
        // dealvalue: items[i][8],       // amount
        seekurl: items[i][0],
        pipeline:"default",
      }
    }
    
    dealCom.push(items[i][3])
    // console.log(i + ". company: " + items[i][3])  

    CreateDeal(dealData)
    // break;
  }
  if (callbackexcCreateAssociation){
    setTimeout(function(){
      console.log("")
      console.log("excCreateAssociation callback starts")
      callbackexcCreateAssociation()
    }, 2000)
  }
}

function excCreateAssociation (){

  setTimeout(function() {}, 2000)
  console.log("===========================")
  console.log("excCreateAssociation starts")

  console.log("")
  console.log("Current dealIdArr: " + dealIdArr)
  console.log("Current contactIdArr: " + contactIdArr)
  
  console.log("")
  console.log(dealCom)
  console.log(contactCom)

  for(var i = 0; i < items.length; i++){
    console.log("")
    console.log(dealCom[i] + ", " + contactCom[i]) 
    console.log(dealIdArr[i] + ", " + contactIdArr[i])
    CreateAssociation(dealIdArr[i], contactIdArr[i])
  //   // break;
  }
}


// https://stackoverflow.com/questions/13421975/calling-three-subsequent-callback-functions
excGetContactByEmail(excCreateDeal)
// excGetContactByEmail()

// excCreateDeal()
// excCreateAssociation()
// excCreateContact()
