
let { username, userEmail} = {
  "username" : "",
  "userEmail" : ""
};


function getUserEmail(inputEmail, inputPass) {
  // https://www.geeksforgeeks.org/how-to-use-selenium-web-driver-and-javascript-to-login-any-website/
  // https://devqa.io/selenium-css-selectors/
  // https://stackoverflow.com/questions/38884522/why-is-my-asynchronous-function-returning-promise-pending-instead-of-a-val

  // Include the chrome driver
  require("chromedriver");

  // Include selenium webdriver
  let swd = require("selenium-webdriver");
  let browser = new swd.Builder();
  let tab = browser.forBrowser("chrome").build();

  // Get the credentials from the JSON file
  // let { email, pass } = require("./credentials.json");

  let { email, pass } = {
    "email": inputEmail,
    "pass": inputPass
  };

  // Step 1 - Opening the geeksforgeeks sign in page
  let tabToOpen =
    tab.get("https://www.seek.com.au/login");
  tabToOpen
    .then(function () {

      // Timeout to wait if connection is slow
      let findTimeOutP =
        tab.manage().setTimeouts({
          implicit: 10000, // 10 seconds
        });
      return findTimeOutP;
    })
    .then(function () {

      // Step 2 - Finding the username input
      let promiseUsernameBox =
        tab.findElement(swd.By.css("#emailAddress"));
      return promiseUsernameBox;
    })
    .then(function (usernameBox) {

      // Step 3 - Entering the username
      let promiseFillUsername =
        usernameBox.sendKeys(email);
      return promiseFillUsername;
    })
    .then(function () {
      console.log("Username entered successfully in");

      // Step 4 - Finding the password input
      let promisePasswordBox =
        tab.findElement(swd.By.css("#password"));
      return promisePasswordBox;
    })
    .then(function (passwordBox) {

      // Step 5 - Entering the password
      let promiseFillPassword =
        passwordBox.sendKeys(pass);
      return promiseFillPassword;
    })
    .then(function () {
      console.log("Password entered successfully in");

      // Step 6 - Finding the Sign In button
      let promiseSignInBtn = tab.findElement(
        swd.By.css(".m1kruc0.m1kruc7.h4lmrv5y.h4lmrvp.h4lmrv5a.h4lmrv4u.h4lmrvy.h4lmrvx.h4lmrv5.h4lmrvg2.h4lmrv4.h4lmrvh.gcqd6g0.gcqd6g5.qorhit15.qorhit17.h4lmrv16.h4lmrv17")
      );
      return promiseSignInBtn;
    })
    .then(function (signInBtn) { 
      // Step 7 - Clicking the Sign In button
      let promiseClickSignIn = signInBtn.click();
      return promiseClickSignIn;
    })
    .then(async function () {
      console.log(
        "Successfully signed in Seek! " +
        "Wait 5 secs"
        );
      await new Promise(resolve => setTimeout(resolve, 5000));
    })
    .then(function () {
      // Step 8 - Going to the Profile page
      console.log("Going to the Profile page")
      tab.navigate().to("https://www.seek.com.au/profile/me") 
    })
    .then(async function () { 

      await new Promise(resolve => setTimeout(resolve, 5000));

      // Step 9 - Getting username

      let promiseUsername = tab.findElement(
        swd.By.css('span[data-hj-masked="true"][data-automation="inline-nudge-name"]')
      );

        return promiseUsername;
    })
    .then(function(getUsername) {
      let name = getUsername.getText()
      return name
    })
    .then(function(name){
      username = name
    })
    .then(function () { 

      // Step 10 - Getting email
      
      // Get email
      let promiseEmail = tab.findElement(
        swd.By.css('span[data-automation="personal-detail-email"]')
      );

        return promiseEmail;
    })
    .then(function(getEmail) {
      let email = getEmail.getText()
      return email
    })
    .then(function(email){
      userEmail = email
    })

    .then(function () {
      console.log("Successfully get Username and Email address! " +
      "Close the broswer");

      // console.log(username, ", ", userEmail);
    })
    .then(function() {
      checkUserEmail()
      tab.quit();
    })
    .catch(function (err) {
      console.log("Error ", err, " occurred!");
      tab.quit();
    });

  }

  function checkUserEmail(){
    console.log(username, ", ", userEmail)
  }

const {inputEmail, inputPass} = {inputEmail: "", inputPass: "" }

getUserEmail(inputEmail, inputPass);
