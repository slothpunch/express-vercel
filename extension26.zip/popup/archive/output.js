No:  1
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  2
===========================
excCreateDeal starts
if false
items[j][8]:  Up to $900 p/day inc Super
rates[0]:  [ '900' ]
Supper included rate:  900
No:  3
===========================
excCreateDeal starts
if false
items[j][8]:  $900 - $950 p.d. + plus super
rates[0]:  [ '900', '950' ]
Supper is excluded:  900
Supper added rate:  994.5
No:  4
===========================
excCreateDeal starts
if false
items[j][8]:  $800 - $950 + Super p.d.
rates[0]:  [ '800', '950' ]
Supper is excluded:  800
Supper added rate:  884
No:  5
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  6
===========================
excCreateDeal starts
if false
items[j][8]:  $800 - $1050 p.d. + including super
rates[0]:  [ '800', '1050' ]
Supper included rate:  800
No:  7
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  8
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  9
===========================
excCreateDeal starts
if false
items[j][8]:  $900 - $960 p.d. + plus super
rates[0]:  [ '900', '960' ]
Supper is excluded:  900
Supper added rate:  994.5
No:  10
===========================
excCreateDeal starts
if false
items[j][8]:  $1k - $1100 p.d. + Inc. Super
rates[0]:  [ '1', '1100' ]

==============
Invalid Job Ad:
    $1k - $1100 p.d. + inc. super
==============

No:  11
===========================
excCreateDeal starts
if false
items[j][8]:  $850 - $900 p.d. + plus super
rates[0]:  [ '850', '900' ]
Supper is excluded:  850
Supper added rate:  939.25
No:  12
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  13
===========================
excCreateDeal starts
if false
items[j][8]:  Pay rate: $850 - $1,050 including Super
rates[0]:  [ '850', '1', '050' ]
Supper included rate:  850
No:  14
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  15
===========================
excCreateDeal starts
if false
items[j][8]:  $1100 per day plus super
rates[0]:  [ '1100' ]
Supper is excluded:  1100
Supper added rate:  1215.5
No:  16
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  17
===========================
excCreateDeal starts
if true
items[j][8]:  inc super
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  18
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  19
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  20
===========================
excCreateDeal starts
if false
items[j][8]:  $950 - $1000 depending on skills
rates[0]:  [ '950', '1000' ]
Supper included rate:  950
No:  21
===========================
excCreateDeal starts
if false
items[j][8]:  $800 - $900 per day
rates[0]:  [ '800', '900' ]
Supper included rate:  800
No:  22
===========================
excCreateDeal starts
if false
items[j][8]:  $850 - $900 per Day + Superannuation
rates[0]:  [ '850', '900' ]
Supper is excluded:  850
Supper added rate:  939.25
No:  23
===========================
excCreateDeal starts
if true
items[j][8]:  Hourly rate contract/ No agency fees
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  24
===========================
excCreateDeal starts
if true
items[j][8]:  Excellent daily rate on offer!
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  25
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  26
===========================
excCreateDeal starts
if false
items[j][8]:  $986 per day (inclusive of super)
rates[0]:  [ '986' ]
Supper included rate:  986
No:  27
===========================
excCreateDeal starts
if false
items[j][8]:  $900 per day, $900 per day inc.
rates[0]:  [ '900', '900' ]
Supper included rate:  900
No:  28
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  29
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  30
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  31
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  32
===========================
excCreateDeal starts
if false
items[j][8]:  Up to $900 plus super per day
rates[0]:  [ '900' ]
Supper is excluded:  900
Supper added rate:  994.5
No:  33
===========================
excCreateDeal starts
if false
items[j][8]:  $900 p.d. + super
rates[0]:  [ '900' ]
Supper is excluded:  900
Supper added rate:  994.5
No:  34
===========================
excCreateDeal starts
if false
items[j][8]:  $900 per day
rates[0]:  [ '900' ]
Supper included rate:  900
No:  35
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  36
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  37
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  38
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  39
===========================
excCreateDeal starts
if false
items[j][8]:  $900 - $950 p.d. + super
rates[0]:  [ '900', '950' ]
Supper is excluded:  900
Supper added rate:  994.5
No:  40
===========================
excCreateDeal starts
if false
items[j][8]:  $700 - $990 p/d + super
rates[0]:  [ '700', '990' ]
Supper is excluded:  700
Supper added rate:  773.5
No:  41
===========================
excCreateDeal starts
if false
items[j][8]:  $850 - $900 plus Super /Day
rates[0]:  [ '850', '900' ]
Supper is excluded:  850
Supper added rate:  939.25
No:  42
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  43
===========================
excCreateDeal starts
if true
items[j][8]:  Competitive Rate
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  44
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  45
===========================
excCreateDeal starts
if false
items[j][8]:  $850 - $900 p.d.
rates[0]:  [ '850', '900' ]
Supper included rate:  850
No:  46
===========================
excCreateDeal starts
if false
items[j][8]:  $800p/d inc. super
rates[0]:  [ '800' ]
Supper included rate:  800
No:  47
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  48
===========================
excCreateDeal starts
if false
items[j][8]:  $900 - $950 p.d. + super
rates[0]:  [ '900', '950' ]
Supper is excluded:  900
Supper added rate:  994.5
No:  49
===========================
excCreateDeal starts
if false
items[j][8]:  $800 - $950 per day
rates[0]:  [ '800', '950' ]
Supper included rate:  800
No:  50
===========================
excCreateDeal starts
if false
items[j][8]:  Up to $1049 p.d. inclusive of Super
rates[0]:  [ '1049' ]
Supper included rate:  1049
No:  51
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  52
===========================
excCreateDeal starts
if false
items[j][8]:  $950 - $1050 p.d.
rates[0]:  [ '950', '1050' ]
Supper included rate:  950
No:  53
===========================
excCreateDeal starts
if false
items[j][8]:  $900 - $1010 p.d. + inc super
rates[0]:  [ '900', '1010' ]
Supper included rate:  900
No:  54
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  55
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  56
===========================
excCreateDeal starts
if false
items[j][8]:  $994.50 P/D Incl Super | 12 Month Contract
rates[0]:  [ '994', '50', '12' ]
Supper included rate:  994
No:  57
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  58
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  59
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  60
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  61
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  62
===========================
excCreateDeal starts
if false
items[j][8]:  $900 - $950 p.d. + Super
rates[0]:  [ '900', '950' ]
Supper is excluded:  900
Supper added rate:  994.5
No:  63
===========================
excCreateDeal starts
if false
items[j][8]:  $800 - $864 p.d. + Super
rates[0]:  [ '800', '864' ]
Supper is excluded:  800
Supper added rate:  884
No:  64
===========================
excCreateDeal starts
if false
items[j][8]:  $800 - $900 per day
rates[0]:  [ '800', '900' ]
Supper included rate:  800
No:  65
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  66
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  67
===========================
excCreateDeal starts
if false
items[j][8]:  $850-930 day rate
rates[0]:  [ '850', '930' ]
Supper included rate:  850
No:  68
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  69
===========================
excCreateDeal starts
if true
items[j][8]:  Competitive daily rate
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  70
===========================
excCreateDeal starts
if false
items[j][8]:  $750 - $950 per day, Benefits: Salary expectation
rates[0]:  [ '750', '950' ]
Supper included rate:  750
No:  71
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  72
===========================
excCreateDeal starts
if false
items[j][8]:  $850 + super
rates[0]:  [ '850' ]
Supper is excluded:  850
Supper added rate:  939.25
No:  73
===========================
excCreateDeal starts
if true
items[j][8]:
rates[0]:  [ '0' ]

==============
Invalid Job Ad:
    0
==============

No:  74
===========================
excCreateDeal starts
if false
items[j][8]:  $800 - $900 p.d.
rates[0]:  [ '800', '900' ]
Supper included rate:  800
No:  75
===========================