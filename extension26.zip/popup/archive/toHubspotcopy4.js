const AXIOS = require('axios');

// https://stackoverflow.com/questions/38296667/getting-unexpected-token-export
const ITEMS1 = require('../firSample.js')
const ITEMS2 = require('../secSample.js')

const ARR1 = ITEMS1.items(); // 89
const ARR2 = ITEMS2.items(); // 197

const ITEMS = ARR1.concat(ARR2);

const CONFIG = { 
  headers: {
    'Content-Type': 'application/json', 
    'Authorization' : 'Bearer pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069'
  }
} 

const OWNER_URL = "https://api.hubapi.com/crm/v3/owners";
const CONTACT_URL = "https://api.hubapi.com/crm/v3/objects/contacts";
const DEAL_URL = "https://api.hubapi.com/crm/v3/objects/deals";

const SUP_EXCL_ARR = ["+ plus super","+super","+ super","+ superannuation", "plus super", "plus superannuation","exclude super","excluding super","excl super","excl of super"];
const HOUR_ARR = ["p.h", "p/h", "hour", "hourly"]

var username = "Insub" 
var userEmail = "insub@mail.com" 
var userOwnerId = ""

var users = "";
var ownerIdArr = new Array;
var ownerEmailArr = new Array;

var dealIdArr = new Array();
var contactIdArr = new Array();
var supInclRate = "";

var j = 0;
var m = 0; 
var iter = 0; // for getOwnerByEmail


function getOwnerByEmail(callback) {
  console.log("")
  console.log("getOwnerByEmail starts")

  AXIOS.get(OWNER_URL, CONFIG)
  .then(function (response) {
    users = response.data.results

    if (callback()){
      console.log("GetOwnerByEmail callback starts")
      callback()
    }
  })
  .catch(function (error) {
    console.log("Owner error");
  })
}

function getIdEmail(){
  for (var i = 0; i < users.length; i++){
    ownerIdArr.push(users[i].id)
    ownerEmailArr.push(users[i].email)
  }

  if (ownerIdArr.length === ownerEmailArr.length){
    if (matchArr(userEmail, ownerEmailArr) === 1) {
      console.log("============================")
      console.log("        userEmail found     ")
      console.log("   userEmail: ", userEmail)
      console.log("   ownerId: ", ownerIdArr[iter-1])
      console.log("============================")
      
      // Set userOwnerId
      userOwnerId = ownerIdArr[iter-1]
      
      setTimeout(function (){
        excGetContactByEmail(excCreateDeal)
      }, 3000)
      
    } else {
      console.log(userEmail, "doesn't exist.")
      console.log("Please add the user first.")
    }
  }
}

function getContactByEmail() {
  console.log("")
  console.log("getContactByEmail starts")
  let cleanedEmail = ITEMS[j][10].toLowerCase().replace(/pty|ltd.|ltd|limited/g, '').replace(/[^a-z0-9@.]/gi, '')
  console.log("Cleaned email: ", cleanedEmail)
  
  AXIOS.get(CONTACT_URL.concat('/',cleanedEmail, '?idProperty=email'), CONFIG)
  
  .then(function (response) {
    // handle success
    console.log("")
    console.log("found contactEmail/" + cleanedEmail);
    console.log("getContactByEmail AXIOS response");

    console.log("getContactByEmail response")

  })
  .catch(function (error) {
    console.log("")
    console.log(cleanedEmail)
    console.log("getContactByEmail error")
    
    // if email doesn't exists, create an email address beforehand:
    // email : no_email@company_name.com --> company_name is used as Primary company in HubSpot

    // handle error
    if (error.response.status === 404) {
      console.log("404 - Email address is NOT found")
      console.log("Create a new email address")

      let company = ITEMS[j][3]
      let email = cleanedEmail
      let phone = ITEMS[j][11]
      phone = phone.toString()

      if (email === "" || !email.includes("@")) {
        // .replace(/\s/g, '') remove white spaces
        email = "no_email@" + company.toLowerCase().replace(/pty|ltd.|ltd|limited/g, '').replace(/[^a-z0-9]/gi, '') + ".com" // remove a white space with
        console.log("no_email is created: ", email)
      }

      if (phone.includes("+61")){
        // pass
      } else if(phone.length === 12){ // pass
      } else if (phone.length === 10) { // 1111222333 -> 1111 222 333
        let phone1 = phone.slice(0, 4);
        let phone2 = phone.slice(4, 7);
        let phone3 = phone.slice(7, 10);
        
        phone = phone1 + " " + phone2 + " " + phone3
        
      } else {
          // phone = "0000 000 000";
      }
      
      // create a new contact
      let newContactData = {
        properties: {
          company: company,
          email: email,
          phone: phone,
        }
      }
      // createContact - Create new contract
      createContact(newContactData)
    } // if statement
    j ++;
  })  // catch
}

function getContact(contactId) {
  AXIOS.get(CONTACT_URL.concat('/',contactId), CONFIG)
  .then(function (response) {
    // handle success
    console.log("found contactId/", contactId,":",response.data);
  })
  .catch(function (error) {
    // handle error
    console.log(error)
  })  
}

// -----------------------------------------------------------------------------------------------------

function createContact(contactData) {

  AXIOS.post(CONTACT_URL, contactData, CONFIG)
  .then(function (response) {
    // handle success
    console.log("")
    console.log("successfully added new contact:",response.data.id);
    console.log("createContact response")
    // Append contact id to contactIdArr 
    contactIdArr.push(response.data.id)
  })
  .catch(function (error) {
    // handle error      
      console.log("")
      console.log("createContact error: ", error.response.status)

      if (error.response.status === 409){
        let getID = error.response.data.message;
        // Extract numbers and join them without spaces -- e.g. ["3", "5", "5"] -> 355
        getID = getID.match(/\d/g).join("");

        // Show existing ID 
        console.log(error.response.data.message)        
        // Add to contactIdArr
        contactIdArr.push(getID)
        
      }
      console.log("contactIdArr length: ", contactIdArr.length)
    }) // catch
}

function createDeal (dealData) {
  console.log("")
  console.log("createDeal starts")
  
  AXIOS.post(DEAL_URL, dealData, CONFIG)
  .then(function (response) {
    console.log("")
    console.log("createDeal response")
    console.log("successfully created deal with dealId:",response.data.id);
    // Append deal id to dealIdArr 
    dealIdArr.push(response.data.id)
    console.log("dealIdArr length: ", dealIdArr.length)

  })
  .catch(function (error) {
    console.log("")
    console.log("createDeal error")
  })
}

function createAssociation(dealID, contactID){
  
  console.log("createAssociation starts ")
  console.log(dealID +", " + contactID)

  let associationUrl = "https://api.hubapi.com/crm/v4/objects/deals/"+dealID+"/associations/contacts/"+contactID;
  const ASSOCIATION_DATA = [ 
    {
      "associationCategory": "HUBSPOT_DEFINED",
      "associationTypeId": 3
    }
  ]
  console.log(associationUrl)
  AXIOS.put(associationUrl, ASSOCIATION_DATA, CONFIG)
  
  .then(function (response) {
    // handle success
    console.log("")
    console.log("successfully associated:", response.data);
    console.log("Association response")
  })
  .catch(function (error){
    //handle error
    console.log("")
    console.log("Association error")
  })  

}

// -------------------------------------------------------------------------------------------------------

function excCreateContact () {
  for (var i = 0; i < ITEMS.length; i ++){
    
    let contactData = 
    {
      properties: {
        fisrtname: ITEMS[i][9],
        email: ITEMS[i][10],
        phone: ITEMS[i][11],
      }
  }
    createContact(contactData)
  }
}


function excGetContactByEmail (callbackexcCreateDeal) {
  // https://stackoverflow.com/questions/3583724/how-do-i-add-a-delay-in-a-javascript-loop
  
  console.log("")
  console.log("=============================")
  console.log("No: ", j)
  console.log("excGetContactByEmail starts")

  getContactByEmail()

  setTimeout(function() {
    // if (j === 1){
    if (j === ITEMS.length){
      console.log(contactIdArr)
      setTimeout(function () {
        console.log("")
        console.log("excGetContactByEmail callback starts")
        callbackexcCreateDeal()
      }, 500)
    }

    if (j < ITEMS.length){
      excGetContactByEmail(excCreateDeal)
      j++;
    }
    j--;
  }, 500)

  // https://community.hubspot.com/t5/HubSpot-Ideas/Get-contact-by-email-api-v3/idi-p/463473
}
    
function excCreateDeal (callbackexcCreateAssociation) {
  console.log("")
  console.log("=============================")
  console.log("No: ", j)
  // Reset j
  if (j === ITEMS.length-1 & m === 0){
    j = 0;
    m ++;
  }

  if (j === ITEMS.length){
    setTimeout(function(){
      // console.log("dealIdArr: ", dealIdArr)
      console.log("")
      console.log("excCreateAssociation callback starts")
      callbackexcCreateAssociation()
    }, 3000)
  }

  console.log("===========================")
  console.log("excCreateDeal starts")

  if (j < ITEMS.length){

    let inputAmountStr = "";
    let dollarIndices = new Array;
    let kIndices = new Array;
    
    // ITEMS[j][8] is Rates
    if ((ITEMS[j][8] == "") || (ITEMS[j][8].match(/\d+/g) == null)) {
      inputAmountStr = "0"
    } else {
      inputAmountStr = ITEMS[j][8]
    }

    inputAmountStr = inputAmountStr.toLowerCase();

    for(var i=0; i<inputAmountStr.length;i++) {
      if (inputAmountStr[i] === "$") dollarIndices.push(i);
      if (inputAmountStr[i] === "k") kIndices.push(i);
    }
    
    // $180k --> dollarIndices[0] = 0 and kIndices[0] = 4 
    if (dollarIndices[0] != null && kIndices[0] != null){
      if ((dollarIndices[0] - kIndices[0] == -3) || (dollarIndices[0] - kIndices[0] == -4)){
        inputAmountStr = inputAmountStr.replace("k", "000")
      }
    }

    const rates = inputAmountStr.match(/\d+/g); // Take only numbers
    
    // supInclRate = "";
    
    // console.log("ITEMS[j][8]: ", ITEMS[j][8])
    console.log("inputAmountStr: ", inputAmountStr)
    console.log("rates[0]: ", rates)

    if (matchArr(inputAmountStr, HOUR_ARR) === 1 & rates[0] > 50){
      console.log("")
      console.log("Description: ", inputAmountStr)
      console.log("Hourly rate: ", rates[0])
      console.log("Hourly rate * 8: ", rates[0]*8)
      console.log("")
      rates[0] = rates[0]*8
    
      checkSuper(rates, inputAmountStr)
    
    } else {
      checkSuper(rates, inputAmountStr)
    }

    let dealData = 
    {
      properties: {            
      dealname: username + " - " + ITEMS[j][3] + " - " + ITEMS[j][2], // username - company_name - title
      dealstage:"presentationscheduled",
      closedate:"",
      hubspot_owner_id: userOwnerId, // owner
      amount: supInclRate,       // amount
      seekurl: ITEMS[j][0],
      amountdetail: ITEMS[j][8],
      pipeline:"default",
      }
    }
    // console.log(dealData)
    createDeal(dealData)
  }

  setTimeout(function () {
    if (j < ITEMS.length){
      j++;
      excCreateDeal(excCreateAssociation)
    }
  }, 500)

}

function excCreateAssociation (){

  console.log("")
  console.log("=============================")
  console.log("No: ", j)
  // Reset j
  if (j === contactIdArr.length & m === 1){
    j = 0;
    m ++;
  }

  if (j == contactIdArr.length){
    console.log("===========================")
    console.log("= Sending to HubSpot ends =")
    console.log("===========================")
    console.log("")
    
    throw("END")
  }
  console.log("===========================")
  console.log("excCreateAssociation starts")
  
  console.log("")
  console.log(dealIdArr[j] + ", " + contactIdArr[j])
  
  createAssociation(dealIdArr[j], contactIdArr[j])
  
  setTimeout(function () {
    
    if (j < contactIdArr.length){
      j++;
      excCreateAssociation()
    }
  }, 500)
}


// -------------------------------------------------------------------------------------------------------

function matchArr(target, pattern){
  // https://stackoverflow.com/questions/37896484/multiple-conditions-for-javascript-includes-method
  // https://www.w3schools.com/jsref/jsref_foreach.asp
  let value = 0;
  iter = 0;
  // Take each element from pattern, in this case supPlusArr 
  pattern.forEach(function(word){ 
      if (value === 0){
        value = value + target.includes(word);
        iter++
      }
    });
    if (value === 1){
      return value = 1
    } else {
      return value = 0
    }
}

function calSuperGst(rates, rate){

  // Super
  if (matchArr(rate, SUP_EXCL_ARR) === 1) {
    console.log("Rate: ", rate)
    console.log("Super is excluded: ", rates[0])
    console.log("Super added rate: ", rates[0]*1.105)
  // GST?
    if (rate.includes("gst")){
      console.log("+ GST found. GST(10%) & super added rate: ", (rates[0]*1.105 + rates[0]*0.1))
      supInclRate = rates[0]*1.105 + rates[0]*0.1
    } else {
      supInclRate = rates[0]*1.105
    }
  } else { // 0 means super is inclusive  
    console.log("Super included rate: ", rates[0])

    if (rate.includes("gst")){
      console.log("+ GST found. GST(10%) added rate: ", rates[0]*1.1)
      supInclRate = rates[0]*1.1
    } else {
      supInclRate = rates[0]
    }
  }
}

function checkSuper(rates, inputAmountStr) {
  // The first number in rates is greater than 300 and less than 3000 
  if (rates[0] > 50 && rates[0] < 3000){
    // if (rates[0] > 300 && rates[0] < 3000){
      calSuperGst(rates, inputAmountStr)
    } 
    // e.g. 6 Month Rolling Contract - Up to $950p/d + GST --> rates[0] is 6 and rates[1] is 950. ['6', '950']. Switch two numbers
  else if (rates[0] < 48 && rates[1] > 300){
    // else if (rates[0] < 100 && rates[1] > 300){
      rates[0] = rates[1]
      calSuperGst(rates, inputAmountStr)
  } else { 
    console.log("")
    console.log("==============")
    console.log("Invalid Job Ad:")
    console.log("   ",inputAmountStr)
    console.log("==============")
    console.log("")
    
    supInclRate = "0"
  }
}

// -------------------------------------------------------------------------------------------------------

// https://stackoverflow.com/questions/13421975/calling-three-subsequent-callback-functions

// Execution order //
// 1. getOwnerByEmail
// 2. excGetContactByEmail
// 3. excCreateDeal
// 4. excCreateAssociation

getOwnerByEmail(getIdEmail)
