const MyClass = require('./axios')

// console.log(MyClass.MyClass())
MyClass.MyClass()