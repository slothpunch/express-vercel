const axios = require('axios');
const XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
const jsdom = require('jsdom');
$ = require('jquery')(new jsdom.JSDOM().window);

async function httpGet(theUrl) {
  // var xmlHttp = null;

  var xmlHttp = new XMLHttpRequest();
  xmlHttp.open( "GET", theUrl, false );
  xmlHttp.send( null ); 
  await new Promise(resolve => setTimeout(resolve, 5000));
  console.log(xmlHttp.responseText)
  
  return xmlHttp.responseText;
}

function extractUserEmail (htmlContent){

  let conName = "";
  let cEmail = "";
  //data-automation="inline-nudge-name"
  if ($('[data-automation="inline-nudge-name"]').length) {
    conName = $('[data-automation="inline-nudge-name"]').eq(0).text();
    console.log("consultant is ", conName);
  } else console.log("name not found");

  //vpetaz0 _1qo31524u _1qo31520 n1psou0
  if ($('[class="vpetaz0 _1qo31524u _1qo31520 n1psou0"] div').length > 1) {
    cEmail = $('[class="vpetaz0 _1qo31524u _1qo31520 n1psou0"] div').eq(0).text();
    console.log("consultant email is ", cEmail);
  } else console.log("email not found");
}

const seekprofileUrl = "https://www.seek.com.au/profile/me";
const seekLogin = "https://www.seek.com.au/login";
// const seekLogin = "https://www.seek.com.au/oauth/login?iss=https%3A%2F%2Flogin.seek.com%2F";
// extractUserEmail(httpGet(seekprofileUrl));
httpGet(seekprofileUrl);
// axiosHttpGet(seekprofileUrl);
// axiosHttpPost(seekLogin)


function axiosHttpGet(theUrl) {
  axios.get(theUrl)
  .then(response =>{
    return response.data;
  })
  .catch(error => {
    console.log(error);
  });
}


function axiosHttpPost(theUrl) {
  axios.post(theUrl, 
      { 
        email: "test",
        passowrd: "123",
      },
      {'Content-Type': 'application/json', }
  )
  .then(response =>{
    return response.data;
  })
  .catch(error => {
    console.log(error);
  });
}