const AXIOS = require('axios');

// https://stackoverflow.com/questions/38296667/getting-unexpected-token-export
const ITEMS1 = require('./firSample.js')
const ITEMS2 = require('./secSample.js')

const ARR1 = ITEMS1.items(); // 89
const ARR2 = ITEMS2.items(); // 187
// const ITEMS = ARR1.concat(ARR2); // 276 -- 2 mins 

const SUP_EXCL_ARR = ["+ plus super","+super","+ super","+ superannuation", "plus super", "plus superannuation","exclude super","excluding super","excl super","excl of super"];
const HOUR_ARR = ["p.h", "p/h", "phr", "hour", "hourly"]

var username = "Insub" 
var userEmail = "insub@mail.com" 
var userOwnerId = "229866130"

const ITEMS = [
  [
  "https://www.seek.com.au/job/58015379?type=standard#sol=38271c10589a34237286e0ec2c6702f9adbaba38",
  "",
  "Data Analyst & Programmer",
  "Place Score",
  "ProfileSaved searchesSaved jobsApplied jobsRecommended jobsSettingsHong KongIndonesiaMalaysiaNew ZealandPhilippinesSingaporeThailandCoursesBusinesses for saleVolunteering 20h ago",
  "Full time",
  "About us",
  "Sydney \u00e2\u20ac\u00a2 CBD, Inner West & Eastern Suburbs",
  // "$55 - $60 p.h.",
  // "$59,000 - $62,000",
  // "$90 - $120phr inc super. All client fees disclosed",
  "up to $1k p.d. + super	",
  "",
  "kate@placescore.org",
  "",
  "",
  "8/8/2022 10:11:33 AM"
  ]
]

let j = 0;
let inputAmountStr = "";
let dollarIndices = new Array;
let kIndices = new Array;

// ITEMS[j][8] is Rates
if ((ITEMS[j][8] == "") || (ITEMS[j][8].match(/\d+/g) == null)) {
  inputAmountStr = "0"
} else if (ITEMS[j][8].includes(",")){
  console.log("Before replace , ", ITEMS[j][8])
  inputAmountStr = ITEMS[j][8].replaceAll(",", "")
  console.log("After replace , ", inputAmountStr)
} else {
  inputAmountStr = ITEMS[j][8]
}

inputAmountStr = inputAmountStr.toLowerCase();

for(var i=0; i<inputAmountStr.length;i++) {
  if (inputAmountStr[i] === "$") dollarIndices.push(i);
  if (inputAmountStr[i] === "k") kIndices.push(i);
}

// $180k --> dollarIndices[0] = 0 and kIndices[0] = 4 
if (dollarIndices[0] != null && kIndices[0] != null){
  if ((dollarIndices[0] - kIndices[0] == -2) || (dollarIndices[0] - kIndices[0] == -3) || (dollarIndices[0] - kIndices[0] == -4)){
    inputAmountStr = inputAmountStr.replace("k", "000")
  }
}

let rates = inputAmountStr.match(/\d+/g); // Take only numbers

// console.log("ITEMS[j][8]: ", ITEMS[j][8])
console.log("inputAmountStr: ", inputAmountStr)
console.log("rates[0]: ", rates)

if (matchArr(inputAmountStr, HOUR_ARR) === 1 & rates[0] > 50){
  console.log("")
  console.log("Description: ", inputAmountStr)
  console.log("Hourly rate: ", rates[0])
  console.log("Hourly rate * 8: ", rates[0]*8)
  console.log("")
  rates[0] = rates[0]*8

  checkSuper(rates, inputAmountStr)

} else {
  checkSuper(rates, inputAmountStr)
}

let dealData = 
{
  properties: {            
  dealname: username + " - " + ITEMS[j][3] + " - " + ITEMS[j][2], // username - company_name - title
  dealstage:"presentationscheduled",
  closedate:"",
  hubspot_owner_id: userOwnerId, // owner
  amount: supInclRate,       // amount
  seekurl: ITEMS[j][0],
  amountdetail: ITEMS[j][8],
  pipeline:"default",
  }
}

console.log(dealData)
function matchArr(target, pattern){
  // https://stackoverflow.com/questions/37896484/multiple-conditions-for-javascript-includes-method
  // https://www.w3schools.com/jsref/jsref_foreach.asp
  let value = 0;
  iter = 0;
  // Take each element from pattern, in this case supPlusArr 
  pattern.forEach(function(word){ 
      if (value === 0){
        value = value + target.includes(word);
        iter++
      }
    });
    if (value === 1){
      return value = 1
    } else {
      return value = 0
    }
}

function calSuperGst(rates, rate){
  // Super
  if (matchArr(rate, SUP_EXCL_ARR) === 1) {
    console.log("Rate: ", rate)
    console.log("Super is excluded: ", rates[0])
    console.log("Super added rate: ", rates[0]*1.105)
  // GST
    if (rate.includes("gst")){
      console.log("+ GST found. GST(10%) & super added rate: ", (rates[0]*1.105 + rates[0]*0.1))
      supInclRate = rates[0]*1.105 + rates[0]*0.1
    } else {
      supInclRate = rates[0]*1.105
    }
  } else { // 0 means super is inclusive  
    console.log("Super included rate: ", rates[0])

    if (rate.includes("gst")){
      console.log("+ GST found. GST(10%) added rate: ", rates[0]*1.1)
      supInclRate = rates[0]*1.1
    } else {
      supInclRate = rates[0]
    }
  }
}

function checkSuper(rates, inputAmountStr) {
  // The first number in rates is greater than 300 and less than 3000 
  if (rates[0] > 50 && rates[0] < 3000){
    // if (rates[0] > 300 && rates[0] < 3000){
      calSuperGst(rates, inputAmountStr)
    } 
    // e.g. 6 Month Rolling Contract - Up to $950p/d + GST --> rates[0] is 6 and rates[1] is 950. ['6', '950']. Switch two numbers
  else if (rates[0] < 48 && rates[1] > 300){
    // else if (rates[0] < 100 && rates[1] > 300){
      rates[0] = rates[1]
      calSuperGst(rates, inputAmountStr)
  } else { 
    console.log("")
    console.log("==============")
    console.log("Invalid Job Ad:")
    console.log("   ",inputAmountStr)
    console.log("==============")
    console.log("")
    
    supInclRate = "0"
  }
}