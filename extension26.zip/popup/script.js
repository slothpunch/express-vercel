// C:\Users\GIS\AppData\Local\Google\Chrome\User Data\Default\Local Extension Settings\oicamkmhdiniogjlccmekoohehnfanbh

chrome.runtime.onMessage.addListener(function (msg, sender) {
    if ((msg.from === 'content') && (msg.subject === 'loadResults')) {
        load_results();
    }

    if ((msg.from === 'content') && (msg.subject === 'updateStatistic')) {
        update_statistic();
    }

    if ((msg.from === 'content') && (msg.subject === 'scriptFinnished')) {
        $("#progress_bar").hide();
    }
});

$(document).ready(function () {

    load_results();

    $("#export").click(function (event) {
        exportTableToCSV.apply(this, [$('table'), "results.csv"]);
    });

    // Export to HubSpot button
    // $("#to_hubspot").onclick(toHubspot ());
    // $("#to_hubspot").click(function() {
    //     toHubspot();
    // });


    $("#to_hubspot").click(function () {
        // toHubspot()
        toProfile()
        
    });
    

let username = "";
let useremail = "";

    $("#to_profile").click(function(){
        chrome.storage.local.get(['username'], function(result) {
            console.log('Value currently is ' + result.username);
            alert('Name: ' + result.username);
            username = result.username;
        });
        chrome.storage.local.get(['useremail'], function(result) {
            console.log('Value currently is ' + result.useremail);
            alert('Email: ' + result.useremail);
            useremail = result.useremail;
        });
    });


    $("#get_profile").click(function () {
        // chrome.storage.local.get(['items'], function (data) {
        //     let items = [];
        //     if (data['items'] && (data['items'] != 'undefined'))
        //         items = data['items'];
            
        //     alert(items[0][14] + ", " + items[0][15])
        // let user_info = []
        // })
        alert(name + ', ' + email)
    });


    $('th.sortable').click(function () {
        var table = $(this).parents('table').eq(0)
        var rows = table.find('tr:gt(0)').toArray().sort(comparer($(this).index()))
        rows.reverse();
        this.asc = !this.asc
        if (!this.asc) {
            rows = rows.reverse()
        }
        for (var i = 0; i < rows.length; i++) {
            table.append(rows[i])
        }
    })

    $("#add_item").click(function () {
        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, function (tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {from: 'popup', subject: 'addItem'});
        });

        return false;
    });

    $("#clear_items").click(function () {
        chrome.storage.local.set({
            items: []
        }, function () {
            load_results();
        });

        return false;
    });
});


function load_results() {
    $('#table_body').html('');
    chrome.storage.local.get(['items'], function (data) {
        let items = [];
        if (data['items'] && (data['items'] != 'undefined'))
            items = data['items'];

        if (items.length) {
            for (let i = 0; i < items.length; i++) {

                let tr_element = '<tr>';

                for (let j = 0; j < items[i].length; j++) {
                    tr_element += '<td>' + items[i][j] + '</td>';
                }

                tr_element += '</tr>';

                $("#items > tbody").append(tr_element);
            }
        }
    });
}

function toProfile() {
    chrome.storage.local.get(['items'], function (data) {
        let items = [];
        if (data['items'] && (data['items'] != 'undefined'))
            items = data['items'];
        
            
        console.log(items)

        // https://stackoverflow.com/questions/957537/how-can-i-display-a-javascript-object#:~:text=on%20this%20post.-,console.,of%20a%20specified%20JavaScript%20object.
        alert(JSON.stringify(items, null, 4))
        console.log(JSON.stringify(items, null, 4))

        // alert(items[0])
        // alert(items[1])
        // alert(items[2])

})};


function exportTableToCSV($table, filename) {
    var $headers = $table.find('tr:has(th)')
            , $rows = $table.find('tr:has(td)')

            // Temporary delimiter characters unlikely to be typed by keyboard
            // This is to avoid accidentally splitting the actual contents
            , tmpColDelim = String.fromCharCode(11) // vertical tab character
            , tmpRowDelim = String.fromCharCode(0) // null character

            // actual delimiter characters for CSV format
            , colDelim = '","'
            , rowDelim = '"\r\n"';

    // Grab text from table into CSV formatted string
    var csv = '"';
    csv += formatRows($headers.map(grabRow));
    csv += rowDelim;
    csv += formatRows($rows.map(grabRow)) + '"';

    // Data URI
    var csvData = 'data:application/csv;charset=utf-8,' + encodeURIComponent(csv);

    $(this)
            .attr({
                'download': filename
                , 'href': csvData
                        //,'target' : '_blank' //if you want it to open in a new window
            });

    //------------------------------------------------------------
    // Helper Functions 
    //------------------------------------------------------------
    // Format the output so it has the appropriate delimiters
    function formatRows(rows) {
        return rows.get().join(tmpRowDelim)
                .split(tmpRowDelim).join(rowDelim)
                .split(tmpColDelim).join(colDelim);
    }
    // Grab and format a row from the table
    function grabRow(i, row) {

        var $row = $(row);
        //for some reason $cols = $row.find('td') || $row.find('th') won't work...
        var $cols = $row.find('td');
        if (!$cols.length)
            $cols = $row.find('th');

        return $cols.map(grabCol)
                .get().join(tmpColDelim);
    }
    // Grab and format a column from the table 
    function grabCol(j, col) {
        var $col = $(col),
                $text = $col.text();

        $text = $text.replace(/\"/g, '&quote;');
        return $text; // escape double quotes

    }
}

function comparer(index) {
    return function (a, b) {
        var valA = get_cell_value(a, index), valB = get_cell_value(b, index)
        return $.isNumeric(valA) && $.isNumeric(valB) ? valA - valB : valA.toString().localeCompare(valB)
    }
}

function get_cell_value(row, index) {
    return $(row).children('td').eq(index).text()
}



// https://stackoverflow.com/questions/19059580/client-on-node-js-uncaught-referenceerror-require-is-not-defined
// https://flaviocopes.com/fix-cannot-use-import-outside-module/

function toHubspot() {
    // alert(location)
    const axios = require('axios').default;

    // alert("1")
    axios.post('https://api.hubapi.com/crm/v3/objects/deals',
    // axios.post('https://api.hubapi.com/deals/v1/deal',
  {            
      properties: 
      [ 
        { value: "test", name: 'dealname' },
        { value: 'appointmentscheduled', name: 'dealstage' },
        { value: 'default', name: 'pipeline' } 
      ] 
  },
  {headers: {
    'Content-Type': 'application/json', 
    'Authorization' : 'Bearer pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069'
    }}  
)
    .then(function (response) {
    // handle success
    console.log(response);
    alert(response)
  })
  .catch(function (error) {
    // handle error
    console.log(error);
    alert(error);
  })
  .then(function () {
    // always executed
  });
  alert("end")


} // toHubspot function 





            // cnosultant's name or gmail to search their hubspopt_owner_id
            // const hubspot = require('@hubspot/api-client');
            
            // const hubspotClient = new hubspot.Client({"accessToken":"pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069"});
            
            // for (let i = 0; i < items.length; i++) {
            //     const BatchInputSimplePublicObjectInput = { inputs: [
            //                     {"properties":{
                                    // "dealname": items[i][1] + " - " + items[i][3] + " - " + items[i][2],
                                    // "dealvalue": items[i][8],
                                    // "seekurl": items[i][0],
                                    // "dealstage":"presentationscheduled",
                                    // "closedate":"2019-12-07T16:50:06.678Z",
                                    // "pipeline":"default",
                                    // "hubspot_owner_id":"910901", // Get consultant's name and search their owner_id 
            //                         }
            //                     }
            //                 ]
            //             }
            

            // } // for loop
