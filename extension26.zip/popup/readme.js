/*

Execution time with 276 items:
    Previous: Using if statements take 7 mins 6 secs
    Current: Using for loops take 5 mins 14 secs

388
7 mins 15 secs

Execution order:
    getOwnerByEmail → getIdEmail → getContactByEmail → createContact → excCreateDeal 
    → createDeal → excCreateAssociation → createAssociation

Functions: 
    1. getOwnerByEmail - Get all the existing users in HubSpot and store them in the users variable.

    2. getIdEmail - Get all the HubSpot IDs and email addresses from users and store them in ownerIdArr and ownerEmailArr. Find if the given email address exists in ownerEmailArr. If exists, get the ID that will be used as the owner ID later. 

    3. getContactByEmail - Check if an item contains the email address. 
        If contains, add the email address to HubSpot, get the contact ID and add the ID to contactIdArr. 
        If doesn’t, create a new email address with the company name (4. createContact), store it to HubSpot, get the contact ID and add the ID to contactIdArr. 
            i.e. no_email@company_name.com
    4. createContact - Create a new contact. If a contact already exists, it gives the contact ID.

    5. excCreateDeal - Calculate superannuation (10.5%) and GST (10%). 
        $90 - $100 per hour ( + super', +GST ) → 90  8 hrs  1.105 (super)  1.1 (GST) = 875.16
    6. createDeal - Create a new deal. But it doesn’t check whether a given deal already exists or not.  

    7. excCreateAssociation - Used to pass contact IDs and deal IDs to createAssociation to create an association 
    8. createAssociation - Create an association

    9. matchArr - Used to check if a given string exists in an array

    10. calSuperGst - Used to calculate super and GST

    11. checkSuper - Used to check if a string contains the words related to superannuation

*/