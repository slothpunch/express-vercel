// Select location value
// https://medium.com/extensions-development/chrome-extension-options-page-9428920f7309


$(function(){
// *** Setting Limit ***
// select limit button of click event from user
    chrome.storage.local.get(['items'], function (data) {
        let items = [];
        if (data['items'] && (data['items'] != 'undefined'))
            items = data['items'];

            // alert(items + " first") 

    $('#btnSave').click(function(){
            // Get the existing time value from input box
            // let userIfo = [];
            
            let name = $('#name').val();
            let email = $('#email').val();

            // if there's name set, then
            if(name) {
                chrome.storage.local.set({username: name}, function() {
                    // alert('Value is set to ' + name);
                    });
            } else {
                alert("Enter name")
            }

            if(email) {
                chrome.storage.local.set({useremail: email}, function() {
                    // alert('Value is set to ' + email);
                    });
            } else {
                alert("Enter email")
            }
            
            if(name !== "" && email !== ""){
                alert(name + ", " + email + " - saved")
                
                // https://developer.chrome.com/docs/extensions/reference/storage/
                chrome.storage.local.get(['username'], function(result) {
                    console.log('Value currently is ' + result.username);
                    alert('Username currently is ' + result.username);
                });

                chrome.storage.local.get(['useremail'], function(result) {
                    console.log('Value currently is ' + result.useremail);
                    alert('Useremail currently is ' + result.useremail);
                });
                
                alert("This page is closing");
                close();
            }

        })
    })
});