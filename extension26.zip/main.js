chrome.runtime.onMessage.addListener(function (msg, sender, response) {
    if (msg.subject === 'addItem') {

        chrome.storage.local.get(['items'], function (data) {
            let items = [];
            let item = [];
            if (data['items'] && (data['items'] != 'undefined'))
                items = data['items'];

            let url = window.location.href;
            let date_time = new Date().toLocaleString();
            date_time = date_time.replace(",", "");
            let username = "";
            let rates = "";
            let work_type = "";
            let reference_number = "";
            let location = "";
            let role_desc = "";
            let contact_email = "";
            let contact_phone = "";
            let contact_name = "";
            // let name = "";
            // let email = "";

            
            if ($('[data-automation="user-account-name"]').length) {
                username = $('[data-automation="user-account-name"]').eq(0).text();
            }

            // let name = $('[data-automation="inline-nudge-name"]').text();
            // let email = $('[data-automation="personal-detail-email"]').text();

            let title = $('[data-automation="job-detail-title"]').text();
            let company = $('[data-automation="advertiser-name"]').text();
            // add its div name?    
            let date_posted = $('[class="yvsb870 _14uh9944u _1qw3t4i0 _1qw3t4i1y _1qw3t4i1 _1d0g9qk4 _1qw3t4ib"]').text();
            date_posted = date_posted.replace("Posted", "").trim();

            if ($('[data-automation="job-detail-work-type"] div').length > 1) {
                rates = $('[data-automation="job-detail-work-type"] div').eq(0).text();
                work_type = $('[data-automation="job-detail-work-type"] div').eq(1).text();
            } else {
                work_type = $('[data-automation="job-detail-work-type"]').text();
            }

            if ($('[class="yvsb870 _14uh994bi"]').length) {
                if ($('[class="yvsb870 _14uh994bi"] div').length > 1) {
                    location = $('[class="yvsb870 _14uh994bi"] div').eq(0).text();
                } else {
                    location = $('[class="yvsb870 _14uh994bi"]').eq(0).text();
                }
            }

            $('[data-automation="jobAdDetails"] p').each(function () {
                let current_item = $(this);
                let details_paragraph = current_item.text();
                if (details_paragraph.includes("reference number") && !reference_number) {
                    let reference_parts = details_paragraph.split("reference number");
                    reference_number = reference_parts[1].trim();
                    reference_number = reference_number.replace(".", "");
                } else if (details_paragraph.includes("Job Reference #") && !reference_number) {
                    let reference_parts = details_paragraph.split("Job Reference #");
                    reference_number = reference_parts[1].trim();
                } else if ((details_paragraph == "The Role:") || (details_paragraph == "About the Role")) {
                    role_desc = current_item.next().text();
                } else if (!contact_name) {
                    if (details_paragraph.includes(" please contact ")) {
                        contact_name = get_data_between(details_paragraph, " please contact ", " on ");
                        if (contact_name == "me") {
                            contact_name = "";
                        }
                    } else if (details_paragraph.includes(" call ")) {
                        contact_name = get_data_between(details_paragraph, " call ", " on ");
                        if (contact_name == "me") {
                            contact_name = "";
                        }
                    } else if (details_paragraph.includes(" write to ")) {
                        contact_name = get_data_between(details_paragraph, " write to ", " on ");
                    } else if (details_paragraph.includes("Consultant:")) {
                        contact_name = get_data_between(details_paragraph, "Consultant:", "");
                    }
                }
            });

            let job_details_text = $('[data-automation="jobAdDetails"]').text();
            if (!contact_name) {
                contact_name = get_data_between(job_details_text, " please reach out to ", " on");
            }

            if (!contact_name) {
                contact_name = get_data_between(job_details_text, " or write to ", " on");
            }

            if (!contact_name) {
                contact_name = get_data_between(job_details_text, "Contact:", ",");
            }

            $('[data-contact-match="true"]').each(function () {
                let contact_href = $(this).attr("href");
                if (contact_href.includes("mailto:")) {
                    contact_email = contact_href.replace("mailto:", "");
                } else if (contact_href.includes("tel:")) {
                    contact_phone = contact_href.replace("tel:", "");
                }
                let parent_text = $(this).parent().text().toLowerCase();
                if (!contact_name) {
                    contact_name = get_data_between(parent_text, "contact ", " at ");
                }
                if (!contact_name) {
                    contact_name = get_data_between(parent_text, "contact ", " on ");
                }
            });

            if (contact_email) {
                $('[data-automation="jobAdDetails"] a').each(function () {
                    let contact_href = $(this).attr("href");
                    if (contact_href.includes("mailto:")) {
                        contact_email = contact_href.replace("mailto:", "");
                    }
                });
            }

            if (!role_desc) {
                role_desc = get_data_between(job_details_text, "THE ROLE", "REQUIREMENTS:");
            }

            if (!role_desc) {
                role_desc = $('[data-automation="jobAdDetails"] p').eq(0).text();
            }

            $('[data-automation="jobAdDetails"] li strong').each(function () {
                let current_item = $(this);
                let details_strong = current_item.text();
                if (details_strong.includes("salary ranging") && !rates) {
                    rates = current_item.next().text();
                } else if (details_strong.includes("Daily Rate:") && !rates) {
                    let rates_parts = details_strong.split("Daily Rate:");
                    rates = rates_parts[1].trim();
                } else if (details_strong.includes("Location:")) {
                    if (!location) {
                        let location_parts = details_strong.split("Location:");
                        location = location_parts[1].trim();
                    }
                } else if (details_strong.includes("locations considered")) {
                    if (!location) {
                        location = current_item.text();
                    }
                }
            });

            $('[data-automation="jobAdDetails"] p strong').each(function () {
                let current_item = $(this);
                let details_strong = current_item.text();
                if (details_strong.includes("please apply via")) {
                    contact_name = get_data_between(details_strong, " to ", " -");
                }
            });

            if (!contact_email) {
                contact_email = get_data_between(job_details_text, "via email", '');
            }

            item.push(url);
            item.push(username);
            item.push(title);
            item.push(company);
            item.push(date_posted);
            item.push(work_type);
            item.push(role_desc);
            item.push(location);
            item.push(rates);
            item.push(contact_name);
            item.push(contact_email);
            item.push(contact_phone);
            item.push(reference_number);
            item.push(date_time);
            // item.push(name);
            // item.push(email);

            items.push(item);

            chrome.storage.local.set({
                items: items
            }, function () {
                chrome.runtime.sendMessage({
                    from: 'content',
                    subject: 'loadResults'
                });
            });
        });
    }
});

function get_data_between(full_string, sep1, sep2) {
    let data = "";
    let paragraph_parts = full_string.split(sep1);
    if (paragraph_parts[1]) {
        if (sep2) {
            let paragraph_parts2 = paragraph_parts[1].split(sep2);
            data = paragraph_parts2[0];
        } else {
            data = paragraph_parts[1];
        }
    }

    return data;
}

$(document).ready(function () {
    let interval = setInterval(function () {
        if ($("article").length) {
            $("article").each(function () {
                let article = $(this);
                let article_text = article.text().toLowerCase();
                let article_salary_text = article.find('[data-automation="jobSalary"]').text().toLowerCase();
                if (!article_text.includes("per hour") && !article_text.includes("p.h.") && !article_text.includes("p/h") && !article_salary_text.includes("ph")) {
                    if (article_text.includes("per day") ||
                            article_text.includes("p.d") ||
                            article_text.includes("day rate contract") ||
                            article_text.includes("daily rate") ||
                            article_text.includes("p/d") ||
                            article_salary_text.includes("pd")) {
                        article.css("background-color", "#e6fff2");
                    } else if (article_text.includes("salary") ||
                            article_text.includes("benefits") ||
                            article_text.includes("competitive base") ||
                            article_text.includes("per annum") ||
                            article_text.includes("p.a.") ||
                            article_text.includes("permanent") ||
                            article_text.includes("perm") ||
                            article_text.includes("full time equivalent") ||
                            article_text.includes("full time equiv") ||
                            article_text.includes("remuneration") ||
                            article_text.includes("package") ||
                            article_text.includes("packaging") ||
                            article_text.includes("fixed term") ||
                            article_text.includes("fixed-term") ||
                            article_text.includes("ftc")) {
                        article.css("background-color", "red");
                    } else if (check_salary_type(article_salary_text) == "per_day") {
                        article.css("background-color", "#e6fff2"); // light green colour 
                    } else if (check_salary_type(article_salary_text) == "per_year") {
                        article.css("background-color", "red");
                    } else if (check_salary_type(article_text) == "per_day") {
                        article.css("background-color", "#e6fff2");
                    }

                }
            });
        }
    }, 1000);
});

function check_salary_type(full_text) {
    let salary_type = "";
    let full_text_temp = full_text.replace("-", " - ");
    let text_parts = full_text_temp.split(" ");
    for (let i = 0; i < text_parts.length; i++) {
        let word = text_parts[i].toString().toLowerCase();
        let numeric_value = 0;
        if (word) {
            let numeric_value_match = word.match(/\d/g);
            if (numeric_value_match) {
                numeric_value = numeric_value_match.join("");
            }
            if (word.includes("$")) {
                if (word.includes("day")) {
                    salary_type = "per_day";
                } else if (!word.includes("k")) {
                    if ((numeric_value.length >= 2) && (numeric_value.length <= 4)) {
                        salary_type = "per_day";
                    } else if ((numeric_value.length >= 5) && (numeric_value.length <= 6)) {
                        salary_type = "per_year";
                    }
                } else if (word.includes("k") && (numeric_value.length >= 2) && (numeric_value.length <= 3)) {
                    salary_type = "per_year";
                }
            } else if ((numeric_value.length >= 5) && (numeric_value.length <= 6)) {
                salary_type = "per_year";
            }
        }
    }

    return salary_type;
}