function toHubSpot() {
  var items = [[1,2,3,4],2,3000, "www.www"]

  var request = require("request");
  console.log("hi")
  var options = { method: 'POST',
      url: 'https://api.hubapi.com/deals/v1/deal',
      headers: 
      { 
      'Content-Type': 'application/json', 
      'Authorization' : 'Bearer pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069'
      },
      body: 
      {            
          properties: 
          [ 
            { value: "123", name: 'dealname' },
            { value: 'appointmentscheduled', name: 'dealstage' },
            { value: 'default', name: 'pipeline' } 
          ] 
      },
                  
  json: true };

  request(options, function (error, response, body) {
  if (error) throw new Error(error);
  });
};




toHubSpot();

// var request = require("request");
// console.log(request)


// var request = require("request");
        
// var options = { method: 'POST',
//     url: 'https://api.hubapi.com/deals/v1/deal',
//     headers: 
//     { 
//     'Content-Type': 'application/json', 
//     'Authorization' : 'Bearer pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069'
//     },
//     body: 
//     {            
//         properties: 
//         [ { value: items[0][1] + " - " + items[0][3] + " - " + items[0][2], name: 'dealname' },  // Consultant Name + Client Name + Role Name -- e.g.(insub - AI ventures - Data Analyst)  
//             { value: 'appointmentscheduled', name: 'dealstage' },
//             { value: items[0][8], name: 'amount' }, 
//             { value: items[0][0], name: 'seekurl' },  
//             { value: 'default', name: 'pipeline' },  // default
//             { value: 'newbusiness', name: 'dealtype' } 
//         ] 
//     },
                
// json: true };

// request(options, function (error, response, body) {
// if (error) throw new Error(error);
// });

// const instance = axios.create({
//   baseURL: 'https://api.hubapi.com/deals/v1/',
//   timeout: 1000,
//   headers: {
//       'Content-Type': 'application/json', 
//       'Authorization' : 'Bearer pat-na1-7aaf65a7-5362-4717-bb60-e1bcdbca5069'
//       }
//   });

// axios.post('/deal', {
//   'dealname': items[0][1] + " - " + items[0][3] + " - " + items[0][2],  // Consultant Name + Client Name + Role Name -- e.g.(insub - AI ventures - Data Analyst)  
//   'dealstage': 'appointmentscheduled',
//   'pipeline': 'default',  // default
//   'amount': items[0][8], 
//   'seekurl': items[0][0],  
//   'dealtype': 'newbusiness', 
  
//   })
//   .then(function (response) {
//   console.log(response);
//   })
//   .catch(function (error) {
//   console.log(error);
//   });